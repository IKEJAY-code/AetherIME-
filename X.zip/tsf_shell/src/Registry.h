#pragma once

#include <windows.h>

HRESULT RegisterTsfServer();
HRESULT UnregisterTsfServer();

